declare module 'buffer-layout' {
  const bl: any;
  export = bl;
}
