# Token Entangler

Add a .env file with REACT_APP_WHITELISTED_AUTHORITY set.

Also edit the valid_mints.json inside the utils folder to have a list of all valid mints (on both sides of the entanglement). Then you're good to go.
