export const MAX_PACK_SET_SIZE = 885;
export const MAX_PACK_CARD_SIZE = 145;
export const MAX_PACK_VOUCHER_SIZE = 1 + 32 + 32 + 32;
export const MAX_PACK_PROVING_PROCESS_SIZE = 1 + 32 + 1 + 32 + 32 + 4 + 800;
