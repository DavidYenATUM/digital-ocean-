## Supported Versions

The following versions are currently being supported with security updates.

| Version | Supported          |
| ------- | ------------------ |
| 1.x     | :white_check_mark: |
| < 1.0   | :x:                |

## Reporting Security Issues

To report a security issue, please follow the guidance on our [security policy](https://docs.metaplex.com/security-policy) page.
